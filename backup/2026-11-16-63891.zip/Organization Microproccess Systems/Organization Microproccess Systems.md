---

kanban-plugin: list

---

## Лекции

- [ ] [[Лекция 1]]
- [ ] [[Лекция 2]]
- [ ] [[Лекция 3]]
- [ ] [[Лекция 4]]
- [ ] [[Лекция 5]]
- [ ] [[Лекция 6]]
- [ ] [[Лекция 7]]
- [ ] [[Лекция 8]]
- [ ] [[Лекция 9]]
- [ ] [[Лекция 10]]




%% kanban:settings
```
{"kanban-plugin":"list","list-collapse":[false],"full-list-lane-width":true}
```
%%